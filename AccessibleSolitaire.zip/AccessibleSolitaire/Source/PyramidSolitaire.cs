﻿using Sa11ytaire4All.Source;
using Sa11ytaire4All.ViewModels;
using Sa11ytaire4All.Views;

namespace Sa11ytaire4All
{
    public enum SolitaireGameType
    {
        NoGame = 0,
        Klondike = 1,
        Pyramid = 2
    }

    public partial class MainPage : ContentPage
    {
        static public SolitaireGameType currentGameType;

        public void LoadKlondikeGame()
        {
            ChangeGameType(SolitaireGameType.Klondike);
        }

        public void LoadPyramidGame()
        {
            ChangeGameType(SolitaireGameType.Pyramid);
        }

        private void ChangeGameType(SolitaireGameType targetGameType)
        {
            SaveSession();

            // Barker Todo: Remove currentGameType now that we have vm.CurrentGameType.
            currentGameType = targetGameType;

            Preferences.Set("CurrentGameType", Convert.ToInt32(currentGameType));

            var vm = this.BindingContext as DealtCardViewModel;
            if (vm != null)
            {
                vm.CurrentGameType = currentGameType;
            }

            var isKlondike = (currentGameType == SolitaireGameType.Klondike);

            CardDeckUpturnedObscuredLower.IsVisible = isKlondike;

            TargetPiles.IsVisible = isKlondike;

            ClearAllPiles();

            if (!LoadSession())
            {
                RestartGame(true /* screenReaderAnnouncement. */);
            }
        }


        private void AddPyramidButtons()
        {
            CardButton button;

            var countOfCardsPerRow = 1;
            var countOfCardsOnCurrentRow = 0;

            var startColumn = 6;
            var currentColumn = 6;

            var vm = this.BindingContext as DealtCardViewModel;

            var setSemanticHeading = true;

            for (int i = 0; i < 28; i++)
            {
                button = new CardButton();

                button.Margin = new Thickness(20, 0, 20, 0);
                button.Padding = new Thickness(0);

                button.IsToggled = false;

                button.BackgroundColor = Colors.White;

                CardPileGridPyramid.Children.Add(button);

                CardPileGridPyramid.SetRow(button, countOfCardsPerRow - 1);
                CardPileGridPyramid.SetRowSpan(button, 3);

                CardPileGridPyramid.SetColumn(button, currentColumn);
                CardPileGridPyramid.SetColumnSpan(button, 2);

                if (setSemanticHeading)
                {
                    button.SetHeadingState(true);

                    setSemanticHeading = false;
                }

                ++countOfCardsOnCurrentRow;

                currentColumn += 2;

                if (countOfCardsOnCurrentRow == countOfCardsPerRow)
                {
                    ++countOfCardsPerRow;

                    countOfCardsOnCurrentRow = 0;

                    --startColumn;

                    currentColumn = startColumn;

                    setSemanticHeading = true;
                }
            }
        }

        private void DealPyramidCardsPostprocess()
        {
            var vm = this.BindingContext as DealtCardViewModel;
            if (vm == null)
            {
                return;
            }

            var cardButtonsUI = CardPileGridPyramid.Children;

            var countCardsPerRow = 1;

            var cardUIIndex = 0;

            for (int i = 0; i < 7; ++i)
            {
                for (int j = 0; j < countCardsPerRow; ++j)
                {
                    var dealtCard = vm.DealtCards[i][j];

                    // Both these are zero-based.
                    dealtCard.PyramidRow = i;
                    dealtCard.PyramidCardIndexInRow = j;

                    dealtCard.OnTop = (dealtCard.PyramidRow == 6);

                    var cardUI = cardButtonsUI[cardUIIndex] as CardButton;
                    if (cardUI != null)
                    {
                        cardUI.IsVisible = true;

                        cardUI.Card = vm.DealtCards[i][j].Card;
                    }

                    ++cardUIIndex;
                }

                ++countCardsPerRow;
            }
        }

        private bool MoveBothUpturnedCards(CardButton cardButtonClicked)
        {
            if ((CardDeckUpturned.Card == null) || (CardDeckUpturnedObscuredHigher.Card == null))
            {
                return false;
            }

            var movedBothUpturnedCards = false;

            var checkForMove = ((cardButtonClicked == CardDeckUpturned) && CardDeckUpturnedObscuredHigher.IsToggled) ||
                               ((cardButtonClicked == CardDeckUpturnedObscuredHigher) && CardDeckUpturned.IsToggled);

            if (checkForMove)
            {
                if (CardDeckUpturned.Card.Rank + CardDeckUpturnedObscuredHigher.Card.Rank == 13)
                {
                    _deckUpturned.Remove(CardDeckUpturned.Card);
                    _deckUpturned.Remove(CardDeckUpturnedObscuredHigher.Card);

                    CardDeckUpturned.Card = null;

                    CardDeckUpturnedObscuredHigher.Card = (_deckUpturned.Count > 0 ?
                                        _deckUpturned[_deckUpturned.Count - 1] : null);

                    CardDeckUpturnedObscuredHigher.IsToggled = false;
                    CardDeckUpturned.IsToggled = false;

                    movedBothUpturnedCards = true;
                }
            }

            return movedBothUpturnedCards;
        }

        private bool CanRemoveUpturnedCardAndPyramidCard(CardButton UpturnedCard, CardButton cardButton)
        {
            if (UpturnedCard.Card == null)
            {
                return false;
            }

            bool canRemoveUpturnedCardAndPyramidCard = false;

            if (UpturnedCard.Card.Rank + cardButton.Card.Rank == 13)
            {
                _deckUpturned.Remove(UpturnedCard.Card);

                SetUpturnedCardsVisuals();

                UpturnedCard.IsToggled = false;

                canRemoveUpturnedCardAndPyramidCard = true;
            }

            return canRemoveUpturnedCardAndPyramidCard;
        }

        private void HandlePyramidCardClick(CardButton cardButton)
        {
            if (cardButton.Card == null)
            {
                return;
            }

            var vm = this.BindingContext as DealtCardViewModel;
            if ((vm == null) || (vm.DealtCards == null))
            {
                return;
            }

            var removeCard = false;

            if (CardDeckUpturned.IsToggled && (CardDeckUpturned.Card != null))
            {
                removeCard = CanRemoveUpturnedCardAndPyramidCard(CardDeckUpturned, cardButton);
                if (removeCard)
                {
                    CardDeckUpturned.Card = null;

                    CardDeckUpturnedObscuredHigher.Card = (_deckUpturned.Count > 1 ?
                                        _deckUpturned[_deckUpturned.Count - 1] : null);
                }
            }

            if (!removeCard)
            {
                if (CardDeckUpturnedObscuredHigher.IsToggled && (CardDeckUpturnedObscuredHigher.Card != null))
                {
                    removeCard = CanRemoveUpturnedCardAndPyramidCard(CardDeckUpturnedObscuredHigher, cardButton);
                }
            }

            CardButton? cardAlreadySelected = null;

            if (!removeCard)
            {
                // Is any card in the pyramid already selected?
                var gridCards = CardPileGridPyramid.Children;

                foreach (var gridCard in gridCards)
                {
                    var card = gridCard as CardButton;
                    if ((card != null) && (card != cardButton) && card.IsToggled)
                    {
                        cardAlreadySelected = card;

                        break;
                    }
                }

                if ((cardAlreadySelected != null) && (cardAlreadySelected.Card != null))
                {
                    // Do the cards add up to 13?
                    var total = cardButton.Card.Rank + cardAlreadySelected.Card.Rank;

                    if (total == 13)
                    {
                        CollectionView? list;
                        var dealtCardAlreadySelected = FindDealtCardFromCard(cardAlreadySelected.Card, false, out list);
                        if (dealtCardAlreadySelected != null)
                        {
                            // Has a card now been revealed? 
                            SetOnTopStateFollowingMove(dealtCardAlreadySelected);

                            vm.DealtCards[dealtCardAlreadySelected.PyramidRow][dealtCardAlreadySelected.PyramidCardIndexInRow].Card = null;
                        }

                        cardAlreadySelected.IsVisible = false;
                        cardAlreadySelected.IsToggled = false;

                        removeCard = true;
                    }
                }
                else if (cardButton.Card.Rank == 13)
                {
                    CardDeckUpturned.Card = null;

                    CardDeckUpturnedObscuredHigher.Card = (_deckUpturned.Count > 1 ?
                                        _deckUpturned[_deckUpturned.Count - 1] : null);

                    removeCard = true;
                }
            }

            if (removeCard)
            {
                CollectionView? list;
                var dealtCard = FindDealtCardFromCard(cardButton.Card, false, out list);
                if (dealtCard != null)
                {
                    // Has a card now been revealed? 
                    SetOnTopStateFollowingMove(dealtCard);

                    vm.DealtCards[dealtCard.PyramidRow][dealtCard.PyramidCardIndexInRow].Card = null;

                    cardButton.IsVisible = false;
                    cardButton.IsToggled = false;
                }
            }
            else
            {
                if (cardAlreadySelected != null)
                {
                    cardButton.IsToggled = false;

                    cardAlreadySelected.IsToggled = false;
                }
            }
        }

        private void SetOnTopStateFollowingMove(DealtCard dealtCard)
        {
            var vm = this.BindingContext as DealtCardViewModel;
            if ((vm == null) || (vm.DealtCards == null))
            {
                return;
            }

            var rowRevealed = dealtCard.PyramidRow - 1;
            if (rowRevealed >= 0)
            {
                // First check whether the card above left is now revealed.
                if (dealtCard.PyramidCardIndexInRow > 0)
                {
                    var cardToLeft = vm.DealtCards[dealtCard.PyramidRow][dealtCard.PyramidCardIndexInRow - 1];
                    if (cardToLeft.Card == null)
                    {
                        var cardAboveToLeft = vm.DealtCards[rowRevealed][dealtCard.PyramidCardIndexInRow - 1] as DealtCard;
                        cardAboveToLeft.OnTop = true;
                    }
                }

                // Next check whether the card above right is now revealed.
                if (dealtCard.PyramidCardIndexInRow < dealtCard.PyramidRow)
                {
                    var cardToRight = vm.DealtCards[dealtCard.PyramidRow][dealtCard.PyramidCardIndexInRow + 1];
                    if (cardToRight.Card == null)
                    {
                        var cardAboveToRight = vm.DealtCards[rowRevealed][dealtCard.PyramidCardIndexInRow] as DealtCard;
                        cardAboveToRight.OnTop = true;
                    }
                }
            }
        }
    }
}